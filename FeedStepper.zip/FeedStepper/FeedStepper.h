/*
	StepperMotor.H - folding library for tb6600 stepper driver
	created by Jared. K. West 4-12-18
	Released into the public domain
*/ 

#ifndef FeedStepper_h
#define FeedStepper_h

#include <Arduino.h>

class FeedStepper
{
 

  int stepPin;
  long interval; //time = speed in micros()
  long stepsLeft;
  long stepsRight;
  int stepState;
  unsigned long previousMicros; 

  public:
  FeedStepper(int pin)
  {

    stepPin = pin;
    pinMode(stepPin, OUTPUT);
    
    stepState = LOW;
    previousMicros = 0; 



  }

    long GrabLeft(unsigned long steps, unsigned long microSeconds)
  {
  	stepsLeft = steps;
	interval = microSeconds;
	unsigned long currentMicros = micros();

	      if (currentMicros - previousMicros >= interval) {
	        // save the last time you blinked the LED
	        previousMicros = currentMicros;
	    
	        // if the LED is off turn it on and vice-versa:
	        if (stepState == LOW) {
	          stepState = HIGH;
	          stepsLeft++;
	          
	        } else {
	          stepState = LOW;
	        }

		    // set the LED with the ledState of the variable:
		    digitalWrite(stepPin, stepState);
		    }
	return stepsLeft;
  }

  

  long FeedLeft(unsigned long steps, unsigned long microSeconds)
  {
  	stepsLeft = steps;
	interval = microSeconds;
	unsigned long currentMicros = micros();

	      if (currentMicros - previousMicros >= interval) {
	        // save the last time you blinked the LED
	        previousMicros = currentMicros;
	    
	        // if the LED is off turn it on and vice-versa:
	        if (stepState == LOW) {
	          stepState = HIGH;
	          stepsLeft--;
	          
	        } else {
	          stepState = LOW;
	        }

		    // set the LED with the ledState of the variable:
		    digitalWrite(stepPin, stepState);
		    }
	return stepsLeft;
  }

  long GrabRight(unsigned long steps, unsigned long microSeconds)
  {
  	stepsRight = steps; 
	interval = microSeconds;
	unsigned long currentMicros = micros();

	      if (currentMicros - previousMicros >= interval) {
	        // save the last time you blinked the LED
	        previousMicros = currentMicros;
	    
	        // if the LED is off turn it on and vice-versa:
	        if (stepState == LOW) {
	          stepState = HIGH;
	          stepsRight++;
	          
	        } else {
	          stepState = LOW;
	        }

		    // set the LED with the ledState of the variable:
		    digitalWrite(stepPin, stepState);
		    }
	return stepsRight;

  }

  long FeedRight(unsigned long steps, unsigned long microSeconds)
  {
  	stepsRight = steps; 
	interval = microSeconds;
	unsigned long currentMicros = micros();

	      if (currentMicros - previousMicros >= interval) {
	        // save the last time you blinked the LED
	        previousMicros = currentMicros;
	    
	        // if the LED is off turn it on and vice-versa:
	        if (stepState == LOW) {
	          stepState = HIGH;
	          stepsRight--;
	          
	        } else {
	          stepState = LOW;
	        }

		    // set the LED with the ledState of the variable:
		    digitalWrite(stepPin, stepState);
		    }
	return stepsRight;

  }



  
};
#endif
/*
	StepperMotor.H - folding library for tb6600 stepper driver
	created by Jared. K. West 4-12-18
	Released into the public domain
*/ 

#ifndef FoldStepper_h
#define FoldStepper_h

#include <Arduino.h>

class FoldStepper
{
 

  int stepPin;
  long interval; //time = speed in micros()
  int stepState;
  long stepsLeft;
  long stepsRight;
  long stepsCenter;
  int stepLimitFold;
  int stepLimitUnfold;
  unsigned long previousMicros; 

  public:
  FoldStepper(int pin, int foldLimit, int unfoldLimit)
  {

    stepPin = pin;
    pinMode(stepPin, OUTPUT);
    stepLimitFold = foldLimit;
    stepLimitUnfold = unfoldLimit;
    stepState = LOW;
    previousMicros = 0; 



  }

 long FoldLeft(unsigned long steps, unsigned long microSeconds)
  {
    stepsLeft = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
    if(stepsLeft != stepLimitFold){
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsLeft++;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
      }
  return stepsLeft;
  }

  

  long UnfoldLeft(unsigned long steps, unsigned long microSeconds)
  {
    stepsLeft = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
    if(stepsLeft != stepLimitUnfold)
    {
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsLeft--;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
      }
  return stepsLeft;
  }

  long FoldRight(unsigned long steps, unsigned long microSeconds)
  {
    stepsRight = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
    if(stepsRight != stepLimitFold)
    {
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsRight++;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
      }
  return stepsRight;
  }

  

  long UnfoldRight(unsigned long steps, unsigned long microSeconds)
  {
    stepsRight = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
    if(stepsRight != stepLimitUnfold)
    {
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsRight--;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
    }
  return stepsRight;
  }

  long FoldCenter(unsigned long steps, unsigned long microSeconds)
  {
    stepsCenter = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
  if(stepsCenter != stepLimitFold)
    {
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsCenter++;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
      }
  return stepsCenter;
  }

  

  long UnfoldCenter(unsigned long steps, unsigned long microSeconds)
  {
    stepsCenter = steps;
    interval = microSeconds;
    unsigned long currentMicros = micros();
    if(stepsCenter != stepLimitUnfold)
    {
        if (currentMicros - previousMicros >= interval) {
          // save the last time you blinked the LED
          previousMicros = currentMicros;
      
          // if the LED is off turn it on and vice-versa:
          if (stepState == LOW) {
            stepState = HIGH;
            stepsCenter--;
            
          } else {
            stepState = LOW;
          }

        // set the LED with the ledState of the variable:
        digitalWrite(stepPin, stepState);
        }
    }  

  return stepsCenter;
  }

};
#endif